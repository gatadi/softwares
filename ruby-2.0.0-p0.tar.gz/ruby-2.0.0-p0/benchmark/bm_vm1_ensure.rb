i = 0
while i<30_000_000 # benchmark loop 1
  i += 1
  begin
    begin
    ensure
    end
  ensure
  end
end

