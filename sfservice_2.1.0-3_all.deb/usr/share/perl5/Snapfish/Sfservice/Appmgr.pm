#!/usr/bin/perl -T
package Appmgr;

use warnings;
use strict;
use File::Spec;
use File::Basename;
use File::Path;
use IO::File;
use POSIX;
use Errno;
use Getopt::Long;
use Data::Dumper;
use Snapfish::Sfservice::Conf;
use Sys::Syslog;


$| =1;
my $DEFAULT_PATH ="/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin";
my $DEBUG;
my $requestor = defined $ENV{'SUDO_USER'} ? $ENV{'SUDO_USER'} : getpwuid($<);
my $nopid;
my $multiproc;

my $LOGGER_INITED=0;

sub new{
    my ($class, $action, $appname, $conf_search_path, $pid_path, $debug) = @_;

    if (!$conf_search_path) {
        die("\$conf_search_path was not defined!");
    }
    if (!$pid_path) {
        die("\$pid_path was not defined!");
    }
    my $self = bless({},$class);
    $self->name($appname);
    $self->conf_file_path(__find_config($conf_search_path, $appname));
    my $conf = Conf->new_from_xml( $self->conf_file_path(), $appname, $action );

    $self->conf($conf);
    $self->pidpath( $pid_path );
    $self->pidfile( $self->pidpath."/".$appname);
    $self->_collect_env_vars( "PATH",$DEFAULT_PATH );
    if( $debug ){
        $DEBUG=1;
    }

    $nopid = $conf->nopid;
    $multiproc = $conf->multiproc;
    my $conf_env = $conf->environment_vars;
    if( $conf_env ){
        my %env = %{ $conf_env };
        $self->_set_env_vars( \%env );
        $self->_add_env_vars();
    }

    return $self;
}

sub _unhash_env_vars{
    my ($self, $hashref) = @_;
    $self->{'env'} = $hashref;
}

sub _collect_env_vars{
    my ($self, $key, $value) = @_;
    $self->{'env'}->{$key} = $value;
}

sub conf{
    return __getter_setter('conf',@_);
}

sub env_vars{
    my ($self) = @_;
    return $self->{'env'};
}

sub _confpath{
    my ($self) = @_;
    return $self->{'conf_path'};
}

sub __find_config {
    my ($conf_path, $appname) = @_;
    my @paths = split(/:/,$conf_path);
    my $path = undef;
    my $found = 0;
    for my $dir (@paths) {
        $path = "$dir/${appname}.xml";
        if (-e $path) {
            $found = 1;
            last;
        }
    }
    if (!$found) {
        die("No config named ${appname}.xml found in " . $conf_path);
    }
    return $path;
}

sub find_config {
    my ($self, $appname) = @_;
    return __find_config($self->_confpath,$appname);
}


sub list {
    my ($class, $conf_path) = @_;
    #File::Find is incompatible with perl's taint mode! ( chdir is reported as insecure )
    #use File::Find;

    #find(sub {
        #if ($_ ne '.' && $_ ne '..' && $_ !~ /\.in$/) {
            #my $appname = $_;
            #$appname =~ s/\.xml$//;
            #push @appnames,$appname;
        #}
    #}, split(/:/,$conf_path));
    
    my %appnames;
    opendir( CONFDIR, $conf_path ) or die( "Failed to open $conf_path for reading!" );
    my @entries = readdir( CONFDIR ) or die ( "Failed to read $conf_path!" );
    for my $entry ( @entries ){
        debug( "directory entry: $entry" );
        if( $entry =~ /.xml$/){ #since we've killed off the custom scripts, all we need is the xml's
            $entry =~ s/\.xml//;
            $appnames{$entry} = "defined";
        }
    }

    my @apps = sort( keys %appnames );
    #get the list of config files, print them out
    print "\n\nList of applications available to manage:\n\n";
    print "- ". join("\n- ", @apps );
    print "\n\n";
}

sub pidfile{
    return __getter_setter('pid_file',@_);
}

sub pidpath{
    return __getter_setter('pid_path',@_);
}

sub output {
    return __getter_setter('output',@_);
}

sub debug{
    if( defined($DEBUG) ){
        print Dumper( @_ );
    }
}

sub __getter_setter {
    my ($key, $self, $value, $safe) = @_;
    if (@_ >= 3) {
        if ( !$safe || defined($value)) {
            debug( "Setting $key to $value");
            $self->{$key} = $value;
        }
    }
    return $self->{$key};
    
}
sub name {
    return __getter_setter('name', @_);
}

sub conf_file_path {
    return __getter_setter('conf_file_path', @_);    
}

sub switch_user{
    my ($self) = @_;

    my $run_as_user = $self->conf->user;
    my @current_usr_data = getpwuid($>);
    my @run_as_data = getpwnam( $run_as_user );
    if( defined $run_as_data[2] ){
        if( $current_usr_data[2] != $run_as_data[2] ){
            #$<=$run_as_data[2];
            #don't do the above. It allows switching back to root after dropping
            #privleges. Always use POSIX::setuid as below.
            setuid( $run_as_data[2] );
            $>=$run_as_data[2];
            $(=$run_as_data[3];
            $)=$run_as_data[3];
            debug( "Switched user to : " . getpwuid($>));
            logger( "info", "Switched user to: ". getpwuid($>));
        }
        if( $> != $run_as_data[2]){
            die( "Failed to switch user to run user: $run_as_user.\n");
        }
    }else{
       die( "Failed to lookup expected run user: $run_as_user.\n");
   } 

}

sub healthcheck{
    print STDERR "I don't actually do anything as yet.\n";
    #my ($app_hash_ref) = @_;
    #my $command = $app_hash_ref->executable();
    #my @commandlist;
    #push @commandlist, $command;
    #if( $app_hash_ref->args() ){
        #push @commandlist, $app_hash_ref->args();
    #}
    #$app_hash_ref->switch_user();
    #system(@commandlist);
    #if ( $? != 0 ){
        #die ( "Failed to run command: $!\n" );
    #}
}

sub restart {
    my ($self) = @_;

    $self->stop;
    $self->start;
}

sub check_is_running {
    my ($self) = @_;
    debug( "Running status check" );
    my $pid_file = $self->pidfile();
    my @keywords = $self->conf->keyword;
    my @pid;
    if ($pid_file && -r $pid_file) {
        push @pid, by_pid($self);
    } elsif( @keywords ){
        push @pid, by_keywords($self);
    }
    
    return @pid;
    

    #i broke these two out so that, if we go into by_pid(), and it has an empty
    #file (undef $pid), we can easily switch to keyword search.
    sub by_pid {
        my ($self) = @_;
        debug("Checking for pid");
        my $pid_file = $self->pidfile();
        my @keywords = $self->conf->keyword();
        my $pid = _read_pidfile( $pid_file );
        $pid = untaint( $pid );
        if( $pid < 1 ){
            debug("Pid not found. Checking for keywords.");
            by_keywords( $self);
        }
        #why do we care if we can kill the process here?
        debug("PID: $pid");
        my $can_kill = kill( 0, $pid );
        if ((!$can_kill && $!{"EPERM"}) || $can_kill) {
            return $pid;
        }
        #this is just cleaning up, but in a weird place
        if (!$can_kill && $!{"ESRCH"}) {
            $pid_file = untaint( $pid_file );
            if( ! $nopid ){
                unlink $pid_file || die "could not remove $pid_file: $!";
            }
        }
        return;
    }

    sub by_keywords {
        my ($self) = @_;
        my @keywords = $self->conf()->keyword();
        debug("KEYWORDS: ", @keywords);
        open(PSOUT,'-|',"ps","--no-headers","-e","--format","pid,user,command:10000");
        my @found_list = <PSOUT>;
        close PSOUT;

        foreach my $keyword (@keywords) {
            @found_list = grep { /$keyword/ } @found_list;
        }
        #exclude ourself...
        @found_list = grep { $_ !~ /^\s*$$\s/} @found_list;
        debug("ALL FOUND PROCESSES:", @found_list);
        if (@found_list == 1 || ( $multiproc && ( scalar @found_list > 1) ) ) {
            
            my @pids = map { m/^\s*(\d+)/?$1:() } @found_list;
            
            #my $pid = $1;
            warn  "Pid file was not found or was not readable, or I didn't find that pid in the process list.\n"
                ."I did find another process that looks like the one you wanted.\n";
            return @pids;
        } elsif (@found_list > 1) {
            debug("FOUND: ",@found_list );
            my @pids = map { m/^\s*(\d+)/?$1:() } @found_list;
            die "found to many pids (improve your keywords): " . join(" ", @pids);
        }
    }
}

sub start {
    my ($self) = @_;

    my $top_pid = $$;
    #get the action specific settings, or load defaults

    my @commandlist = $self->get_command_list('start');

    #make sure we have SOME kind of command to run!
    if( ! @commandlist ){
        die ( "You failed to provide a script in the conf for ". $self->name ."\n");
    }
    debug( "COMMAND: ", @commandlist );

    my @running = $self->check_is_running();
    if ( scalar @running > 0 && $running[0] ne '' ) {
        die ( "Attempted to start an already running application with pids: " . join (' ',@running) );
    }

    if ( $self->safe_run( 1, @commandlist ) ){
        debug("Start completed.");
    } else {
        die (join(" ",@commandlist) . " failed to start: %d, %d, %d", $?&127,$?&128,$?>>8);
    }
    
}

sub get_command_list {
    my ($self, $action) = @_;
    debug("GET COMMAND FOR ACTION: ", $action);
    my $command = $self->conf()->executable($action);
    my @commandlist = ($command);
    my @args = $self->conf()->args($action);
    push @commandlist, @args;
    debug("RETURNED COMMAND:", @commandlist);
    return @commandlist;
}

sub stop {
    my ($self) = @_;
    my $timeouts_str = $self->conf->timeout;
    my $kill_schedule_str = $self->conf->killschedule;
    my $pid_file = $self->pidfile;
    #make sure we have SOME kind of command to run!

    my @pid = $self->check_is_running();
    if ( scalar @pid < 1 || $pid[0] eq '' ) {
        return 1;
    }

    my @commands = $self->get_command_list( 'stop' );
    my $prog = shift @commands;
    $self->safe_run( 0, $prog, @commands );

    my ( $timeouts, $kill_schedule ) = _parse_timeouts_killsched( $timeouts_str, $kill_schedule_str );
    for my $pid ( @pid ){
        if( ! _stop_helper($pid, $timeouts, $kill_schedule) ){
            die("Failed to stop ". $self->name );
        }
    }
    if( $pid_file ){
        $pid_file = untaint( $pid_file );
        if ($pid_file && -e $pid_file && ! $nopid ) {
            unlink ($pid_file) || die ("Could not remove $pid_file on exit");
            debug("Deleted $pid_file");
        }
    }
        
    debug( "Stop completed." );
    return 1;
}
    
sub safe_run {
    my( $self, $daemonize, @cmd ) = @_;
    # two modes of operation
    # daemonize: (1)
    #   run exec on @cmd in a double-forked process, I/O redirected to file.
    #   
    # daemonize: (0)
    #   run exec on @cmd.
    #debug("RUNNING: $prog","ARGS:", @args);
    debug("RUNNING: ", @cmd );

    my $pid = fork;
    if( $pid != 0 ){
        #parent
        waitpid( $pid, 0 );
        if ($? == -1) {
            print STDERR "failed to waitpid: $!\n";
            return( 0 );
        }
        elsif ($? & 127) {
            print STDERR sprintf("child died with signal %d, %s coredump\n",
                   ($? & 127),  ($? & 128) ? 'with' : 'without');
            return( 0 );
    
        }
        elsif($? >> 8 != 0) {
            print STDERR sprintf("child exited with value %d\n", $? >> 8);
            return( 0 );
        }
        debug( "Returned: $pid, Exit value: $?");
        return(1);
        #parent returns here (but keeps going!)
    }
    #in the child here!
    $self->switch_user();
    if ( $daemonize && ! $DEBUG ){
        #in debug mode, we run commands in the foreground
        $pid = fork;
        if( $pid != 0 ){
            #child
            exit(0);
            #child done here
        }
        #grandchild
        #redirect standard in/out
        my $output = $self->conf->output;
        close STDOUT;
        close STDERR;
        close STDIN;
        open STDOUT, ">", $output || die "Could not redirect standard out";
        open STDERR,">&", \*STDOUT || die "Could not dup standard error: $!";
        
        my $nopid = $self->conf->nopid;
        debug("NOPID: ", $nopid );
        if( ! $nopid ){
            
            my $pidfile = untaint( $self->pidfile );
            open( WRITEPID, ">", $pidfile ) or die logger("err","Could not write to $pidfile $!");
            print WRITEPID "$$";
            close WRITEPID;
        }
        #disown the terminal and create a new sid and pgid
        POSIX::setsid();
        #this doesn't work. Not sure why, but this is keeping the PID from
        #being recorded correctly.
        #my $ret = exec {$prog} @args;

        my $ret = exec {$cmd[0]} ( @cmd );

        #print STDERR (" Failed to exec $ret: " . join(" ",$prog, @args));
        print STDERR (" Failed to exec $ret: " . join(" ",@cmd));
        exit(-1);
        #grandchild done here
    } elsif ( ! $daemonize || ($daemonize && $DEBUG) ){
        
        #still in child.
        #my $ret = exec {$prog} @args;
        my $ret = exec { $cmd[0] } ( @cmd );
        #print STDERR (" Failed to exec $ret: " . join(" ",$prog, @args));
        print STDERR (" Failed to exec $ret: " . join(" ",@cmd));
        exit(-1);
        #child done here
    } else {
        
        die( "safe_run got an unexpected run mode! \$daemonize: $daemonize, \$DEBUG: $DEBUG");
    }
}


sub _parse_timeouts_killsched {
    my ($timeouts_str, $kill_schedule_str) = @_;

    my @timeouts;
    my @kill_schedule;

    if ($timeouts_str) {
        @timeouts = split(/\//,$timeouts_str);
    }
    if ($kill_schedule_str) {
        @kill_schedule = split ( /\//,$kill_schedule_str);
    }
    if (@timeouts != 0 && scalar(@timeouts) != scalar(@kill_schedule)+1) {
        die ("timeout must have exactly one more elements than kill_schedule");
    }
    return ( \@timeouts, \@kill_schedule );
}


sub _stop_helper {
    my ($pid, $timeouts_ref, $next_signals_ref) = @_;
    debug("Running _stop_helper");
    my $timeout_exceeded = 0;
    my $timecount = 0;
    my @timeouts = @{$timeouts_ref};
    debug("TIMEOUTS: ", @timeouts);
    my @next_signals = @{$next_signals_ref};
    debug("SIGNALS: ", @next_signals);
    my $command_timeout = $timeouts[0];

    while (kill(0,$pid) && !$timeout_exceeded) {
        sleep(1);
        $timecount++;
        if ($timecount % 5 ==0) {
            print ".";
        }
        if ($command_timeout != 0 && $timecount > $command_timeout) {
            $timeout_exceeded = 1;
        }
    }
    if (!$timeout_exceeded) {
        return 1;
    }
    if ($#next_signals) {
        my $next_signal = $next_signals[0];
        debug("trying signal: $next_signal");
        kill ($next_signal, $pid);
        return _stop_helper($pid, [@timeouts[1..$#timeouts]], [@next_signals[1..$#next_signals]]);
    }
    print "timeout exceeded!\n";
    return 0;
}

sub kill_app {
    my ($self, $pid) = @_;
    my $pid_file = $self->pidfile;
    debug("Running kill_app");
    #setup stop_helper
    my ( $timeouts, $killschedule ) = _parse_timeouts_killsched( $self->conf->timeout, $self->conf->killschedule );
    #run stop_helper
    my $ret = _stop_helper( $pid, $timeouts, $killschedule );
    if( $ret ){
        die "Kill failed to stop your app!\n";
    }
    if ($pid_file && -e $pid_file) {
        unlink ($pid_file) || die ("Could not remove $pid_file on exit");
        debug("Deleted $pid_file");
    }
}

sub _read_pidfile {
    #we return the pid value as a hash key to avoid
    #it being considered "tainted" by perl's security systems
    my $pid_file = shift @_;
    open PIDFILE,"<$pid_file" or die "could not open $pid_file: $!";
    my $pid = readline(PIDFILE);
    close PIDFILE;
    chomp($pid);
    debug("PID from file: $pid");
    return $pid;
}

sub untaint{
    my ( $arg ) = @_;
    #this is basically validating the variable passed in.
    #variables that contain ONLY alphanum, \, -, _, or . are allowed.
    #returned value is untainted.
    if( ! $arg ){
        die( "No value passed to untaint!\n");
    }
    if( $arg =~ /^([-\/\w.]+)$/ ){
        return $1;
    } else {
        logger("err", "Session terminated due to tainted data. $arg");
        die( "Tainted data found! $arg\n");
    }
}

sub untaint_env{
    my ($self) = @_;
    delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};   # Make %ENV safer
    #also, items in $ENV{PATH} can only be writable by the OWNER of the path
    $ENV{'PATH'} = $DEFAULT_PATH;
    debug("PATH set to :", $ENV{'PATH'});
}

sub _add_env_vars{
    my ($self) = @_;
    my %env_stuff = %{ $self->env_vars() };
    foreach my $env_var ( keys %env_stuff ){
        $env_var = $env_var;
        my $env_val = untaint( $env_stuff{$env_var} );
        debug("Adding to ENV:", $env_var, $env_val);
        $ENV{$env_var} = $env_val;
    }
}

sub logger{
    my $log_level = shift @_;
    my ($message) = @_;
    #syslog setup
    my $ident = "APPMGR"; #<--prepended to each log entry
    my $logopt = "pid"; #<--include PID with each log entry
    my $facility = 'LOG_LOCAL0'; #<--which log to write to
    #i know the below looks bad/wrong/could be better,
    #but dont mess with it. it works. If you can figure out how to both
    #make this prettier and continue to get the logging into syslog,
    #be my guest. Make sure it works before you check it in.
    openlog($ident,$logopt,$facility);
    syslog( $log_level, $message);
    #if you don't EXPLICITLY close syslog, then you can get moments when
    #it tries to open more than one syslog at a time, thereby breaking
    #the Fifth Rule of Sys::Syslog. If you want to know what that rule says,
    #you should probably obey the Eigth Rule of Sys::Syslog too.
    #hint: perldoc Sys::Syslog
    closelog();
}

#dont remove this. modules must return true.
1;
