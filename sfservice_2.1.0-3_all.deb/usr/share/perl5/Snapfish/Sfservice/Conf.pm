#!/usr/bin/perl -T
package Conf;

use strict;
use warnings;
use XML::Simple;
use Data::Dumper;
use File::stat qw( :FIELDS );
use File::Basename;
use File::Spec;
use Carp;

our @ISA = qw( );

#Normalization of all options
#from defaults to action blocks
#see sample xml conf file at bottom

sub new_from_xml {
    my ($class, $conf_path, $appname, $action) = @_;

    my $self = bless({},$class);

    $self->conf_file_path($conf_path);
    $self->action($action);
    
    my $fh = IO::File->new;

    if (-d $conf_path) {
        die "$conf_path is a directory!";
    }
    
    $fh->open($conf_path,"<") || die ("Could not open $conf_path: $!");

    #it is critical that we stat the $fh not the path here.
    #otherwise there is a race condition where the file
    #can be replaced under us.
    #this is especially valid in production where the sticky
    #bit is set on the sfservice script directory
    my $fh_owner = stat($fh)->uid();

    my $default_output_path = "logs/$appname.log";
    
    my %conf_hash = _parse_xml( $fh );
    $self->_load_environment_adds( \%conf_hash );
    $self->_load_defaults( \%conf_hash , $default_output_path);
    $self->_load_sections( \%conf_hash);

    $self->_validate_conf();
    
    my $run_user = $self->user;
    my (undef,undef,$run_uid) = getpwnam($run_user);

    my ($fh_owner_name) = getpwuid($fh_owner);
    
    if ($fh_owner != 0 && $run_uid != $fh_owner) {
        die ("$conf_path is owned by $fh_owner_name but must be either owned by root, or owned by the same user you are requesting to run as ($run_user)");
    }
    
    return $self;
}

sub output {
    my ($self) = @_;
    my $result = undef;
    if ($self->_defaults('output')) {
        $result = File::Spec->catfile($self->approot,$self->_defaults('output'));
    }
    return $result;
}

sub __getter_setter {
    my ($key, $self, $value, $safe) = @_;
    if (@_ >= 3) {
        if ( !$safe || defined($value)) {
            $self->{$key} = $value;
        }
    }
    return $self->{$key};
    
}

sub action {
    return __getter_setter('action',@_);
}

sub conf_file_path {
    return __getter_setter('conf_file_path',@_);
}

sub environment_vars {
    my ($self) = @_;
    return $self->{'env'};
}


sub _defaults {
    my ($self, $key, $value) = @_;
    if (@_ >= 3) {
        $self->{'defaults'}{$key} = $value;
    }
    return $self->{'defaults'}{$key};
}

sub nopid {
    my ($self) = @_;
    return $self->_check_nopid;
}

sub approot {
    my ($self) = @_;
    return $self->_defaults('approot');
}

sub _check_path_ownership{
    my ($self, $path) = @_;
    #entire chain to the file needs to be either
    #owned by root or owned by the owner of the conf file,
    #which must also match the user defined in the conf file.
    #FFS
    my( $filename, $directories ) = fileparse( $path );
    my $tmppath;
    my @dirs = File::Spec->splitdir( $directories );
    for my $p ( @dirs ){
        $tmppath .= $p. "/";
        my $stat = stat( $tmppath ) or die ("Failed to stat $tmppath");
        my ($owner) = getpwuid( $stat->uid );
        if( $owner ne $self->user && $owner ne "root" ){
            die( "Ownership of $path is broken at $tmppath");
        }
    }
    my $stat = stat( $path ) or die ("Failed to stat $path");
    my ($owner) = getpwuid( $stat->uid );
    if( $owner ne $self->user && $owner ne "root" ){
        die( "Ownership of $path is broken. Must be root or ". $self->user );
    }
    return 1;
}

sub executable {
    my ($self, $action) = @_;
    if( ! $action ){
        $action = $self->action;
    }
    my $exe = $self->lookup_section('executable',$action);
    #check and see if executable is an absolute path
    $exe = $self->approot . $exe;
    $self->_check_path_ownership( $exe );

    return $exe; 
}

sub lookup_section {
    my ($self, $key, $action) = @_;
    my $section;
    #let defaults be the default! :P
    if( ! defined( $action ) || ! defined( $self->{'action_confs'}{$action}{$key} ) ){
        $section = $self->{'defaults'};
    } else {
        $section = $self->{'action_confs'}{$action};
    }

    my $value;
    if (defined($section) && defined($section->{$key})) {
        $value = $section->{$key};
    } 
    return $value;
}

sub killschedule {
    my ($self, $action) = @_;
    return $self->lookup_section('killschedule', $action);
}

sub timeout {
    my ($self, $action) = @_;
    return $self->lookup_section('timeout', $action);
}

sub user {
    my ($self) = @_;
    return $self->_defaults('user');
}

sub keyword {
    my ($self) = @_;
    return $self->_defaults('keyword');
}

sub multiproc{
    my ($self) = @_;
    return $self->_is_multiprocess;
}

sub args {
    my ($self,$action) = @_;
    my $value = $self->lookup_section('args',$action);
    my @result;
    if (!defined($value)) {
        @result = ();  
    } elsif (ref($value) eq 'ARRAY') {
        @result = (@$value);
    } elsif (ref ($value) eq '') {
        @result = ($value);
    } else {
        die("expected 'args' section to be an array or scalar but found " . ref($value));
    }
    return @result;
}

sub pidfile {
    return __getter_setter('pidfile', @_);
}


sub _load_sections {
    my ($self, $conf_ref) =@_;
    if ( exists $conf_ref->{'commands'} ){
            $self->{'action_confs'} = $conf_ref->{'commands'};
    } else {
        die( $self->conf_file_path . " does not contain any command sections");
    }
}

sub _load_defaults{
    my ($self, $conf_ref,$default_output_path) = @_;
    if ( exists $conf_ref->{'defaults'} ){
        $self->{'defaults'} = $conf_ref->{'defaults'};
    } else {
        die($self->conf_file_path . " does not contain section: defaults");
    }

    if (! $self->_defaults('output')) {
        $self->_defaults('output',$default_output_path);
    }
}

sub _load_environment_adds{
    my ($self,$conf_ref) = @_;
    if ( exists $conf_ref->{'env'} ){
        $self->{'env'} = $conf_ref->{'env'};
    }

}

sub _check_nopid{
    my $conf_ref = shift @_;
    if ( defined $conf_ref->{'nopid'} ){
        return 1;
    }
    return 0;
}

sub _is_multiprocess{
    my $conf_ref = shift @_;
    if ( defined $conf_ref->{'multiprocess'} ){
        return 1;
    }
    return 0;
}

sub _parse_xml{
    my $conf_fh = shift @_;
    my $xml = new XML::Simple;
    my $data = $xml->XMLin($conf_fh);
    return %{$data};
}

sub _validate_conf{
    my ($self) = @_;
    
    #make sure the user to run as actually exists on this system
    _test_user_exists( $self->user() );

    #make sure the application exists in the given path and has the expected
    #executable with the correct permissions
    $self->_test_app_path( $self->approot() , $self->executable() );

}

sub _test_app_path{
    my ( $self ) = @_;
    #my $app_path = shift @_;
    #my $executable = shift @_;
    die( "Application path is not defined in " . $self->conf_file_path ) unless ( $self->approot );
    die( "Directory ".$self->approot." does not exist") unless ( -d $self->approot );
    die( "Executable is not defined in " . $self->conf_file_path) unless ( $self->executable );
    die( "Executable ".$self->executable." does not exist!") unless ( -e $self->executable );
    die( "Executable ".$self->executable." is not executable!") unless ( -x $self->executable );
}

sub _test_user_exists{
    my $user = shift @_;
    my @usr_data = getpwnam( $user );
    if ( ! @usr_data ){
        die( "Run user $user does not exist on this system!\n");
    }
}

1;

#Sample conf file:
#<service>
    #<name>snapcat</name>
 	#<defaults>
  		#<output>logs/snapcat.out</output>
		#<executable>bin/catalina.sh</executable>
		#<approot>%%approot%%</approot>
   		#<killschedule>15/9</killschedule>
   		#<timeout>30/15/5</timeout>
        #<user>snapfish.starter</user>
        #<keyword>DSNAPCAT</keyword>
        #<env>
            #<var>
                #<name>VARNAME</name>
                #<val>varvalue</val>
            #</var>
        #</env>
 	#</defaults>
 	#<commands>
  		#<start>
   			#<args>run</args>
        #</start>
  		#<stop>
   			#<args>stop</args>
  		#</stop>
 	 	#<restart />
		#<kill />
  		#<threaddump />
  		#<heapdump />
  		#<healthcheck />
		#<status />
 	#</commands>
#</service>
